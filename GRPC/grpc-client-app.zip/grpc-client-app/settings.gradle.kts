rootProject.name = "grpc-client-app"
