package com.adcb.grpc.client.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrpcClientAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
