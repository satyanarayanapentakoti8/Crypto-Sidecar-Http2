package com.adcb.grpc.client.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrpcClientAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrpcClientAppApplication.class, args);
	}

}
