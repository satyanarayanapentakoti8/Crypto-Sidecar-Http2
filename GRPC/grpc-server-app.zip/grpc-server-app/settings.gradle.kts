rootProject.name = "grpc-server-app"
