package com.adcb.grpc_server.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrpcServerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
